﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupSteakHouseProject
{
    public partial class frmSignUp : Form
    {
        frmLogin login;
        public frmSignUp(frmLogin Login)
        {
            InitializeComponent();
            login = Login;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            login.Show();
            this.Close();
        }
    }
}
