﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupSteakHouseProject
{
    public partial class frmMenu : Form
    {
        public int intSecurityLevel = 0;
        public int UserID = 0;

        public frmMenu()
        {
            InitializeComponent();
        }
    }
}
