﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Net.Mail;


namespace GroupSteakHouseProject
{
    class ProgOps
    {
        //connection string
        private const string CONNECT_STRING = @"Server=cstnt.tstc.edu;Database=inew2330su21;User Id=group1su212330;password=1587159";
        //build a connection to database
        private static SqlConnection _cntDatabase = new SqlConnection(CONNECT_STRING);


        public static void OpenDatabase()
        {
            //method to open database
            try
            {
                _cntDatabase.Open();
            }
            catch (Exception ex)
            {
                _cntDatabase.Close();
                OpenDatabase();
            }
        }

        public static void CloseDatabaseDispose()
        {
            //method to close database and dispose of the connection object
            //close connection
            _cntDatabase.Close();
            //dispose of the connection object and command, adapter and table objects
            _cntDatabase.Dispose();
        }

        public static void CloseDatabase()
        {
            //method to close database and dispose of the connection object
            //close connection
            _cntDatabase.Close();
        }

        public static void Login(TextBox tbxUsername, TextBox tbxPassword, frmLogin login, frmMenu menu)
        {

            OpenDatabase();

            //strings command for userId 
            string sqlquery = "SELECT userID, username, password, securityLevel FROM group1su212330.Login WHERE userID = @userID";            

            //command query
            SqlCommand cmd = new SqlCommand(sqlquery, _cntDatabase);
            cmd.Parameters.AddWithValue("@username", tbxUsername.Text);
            SqlDataReader rd = cmd.ExecuteReader();

            //if username is found
            if (rd.Read())
            {
                //sets strings for returned values
                string UserID = rd.GetValue(0).ToString();
                string Username = rd.GetValue(1).ToString();
                string Password = rd.GetValue(2).ToString();
                string SecurityLevel = rd.GetValue(3).ToString();

                int intSecLevel = 0;
                int intUserID = 0;

                int.TryParse(SecurityLevel, out intSecLevel);
                int.TryParse(UserID, out intUserID);

                //if returned username is same as one entered
                if (Username == tbxUsername.Text)
                {
                    //checks if password is same as one entered
                    if (Password == tbxPassword.Text)
                    {
                        //opens up next form and closes reader
                        menu.intSecurityLevel = intSecLevel;
                        menu.UserID = intUserID;
                        menu.Show();
                        login.Hide();
                        rd.Close();
                    }

                    //if password is not same error pops up and reader closes
                    else
                    {
                        MessageBox.Show("Password is Incorrect.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        rd.Close();
                    }
                }
                else
                {
                    //username not found message
                    MessageBox.Show("Username is not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    rd.Close();
                }
            }

        }



    }
}
